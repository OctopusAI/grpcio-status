gRPC Python Status Proto
===========================

Reference package for GRPC Python status proto mapping.

Supported Python Versions
-------------------------
Python >= 3.7

Dependencies
------------

Depends on the `grpcio` package, available from PyPI via `pip install grpcio`.
